<?php

namespace iio\libmergepdf;

/**
 * Base exception
 */
class Exception extends \Exception
{
}
