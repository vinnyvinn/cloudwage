<?php

class Pearlike2_Foo
{
    public static $loaded = true;
}
