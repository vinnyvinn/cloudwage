<?php

/*
 * foo
 */

declare (strict_types = 1);

namespace Namespaced;

class WithStrictTypes
{
}
