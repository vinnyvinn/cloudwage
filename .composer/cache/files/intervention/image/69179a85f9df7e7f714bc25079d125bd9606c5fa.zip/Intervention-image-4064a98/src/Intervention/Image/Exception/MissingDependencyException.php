<?php

namespace Intervention\Image\Exception;

class MissingDependencyException extends \RuntimeException
{
    # nothing to override
}
