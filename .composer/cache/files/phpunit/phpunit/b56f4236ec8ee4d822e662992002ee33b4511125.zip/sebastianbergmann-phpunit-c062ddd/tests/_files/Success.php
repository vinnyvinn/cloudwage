<?php
class Success extends PHPUnit_Framework_TestCase
{
    protected function runTest()
    {
    }
}
